# -*- coding: utf-8 -*-
"""Serie TV e programmi on demand di Medi1 TV (medi1tv.com/ashamil).

Non dipende da Kodi. Struttura del sito:
  emissions.aspx?type=N  -> serie di un genere
  emission.aspx?id=N     -> episodi di una serie (video.aspx?id=N)
  video.aspx?id=N        -> iframe ../embed/video-ashamil.aspx?id=<file>&t=N
  embed                  -> cheminhttp = '//vod.medi1tv.com/<file>.mp4'
"""
import html
import json
import os
import re
import threading
import time

from sources import fetch

BASE = "https://medi1tv.com/ashamil/"
EMBED_BASE = "https://medi1tv.com/embed/"
CACHE_MAX_AGE = 3 * 3600

# Generi del menu del sito: (type, nome italiano). None = tutte le serie.
GENRES = [
    ("2", "Serie marocchine"),
    ("3", "Serie arabe"),
    ("4", "Drammatiche"),
    ("5", "Commedie"),
    ("6", "Documentari e programmi"),
    ("1", "Tutti i titoli"),
]

_ORDINALS = {"الأول": 1, "الثاني": 2, "الثالث": 3, "الرابع": 4, "الخامس": 5,
             "السادس": 6, "السابع": 7, "الثامن": 8, "التاسع": 9, "العاشر": 10}
_lock = threading.Lock()


def _clean(s):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", s))).strip()


def _season(title):
    """Numero di stagione da titoli come 'حياتهم ـ الموسم الثاني', altrimenti None."""
    m = re.search(r"الموسم\s+(\S+)", title)
    if not m:
        return None
    w = m.group(1)
    return int(w) if w.isdigit() else _ORDINALS.get(w)


def _episode_number(title):
    m = re.search(r"(\d+)", title)
    return int(m.group(1)) if m else None


class Catalog(object):
    """Catalogo con cache su disco (generi e serie 3 ore, episodi per serie 3 ore)."""

    def __init__(self, cache_file, log=lambda msg: None):
        self.cache_file = cache_file
        self.log = log
        self._data = None

    # ------------------------------------------------------------ cache
    def _load(self):
        if self._data is None:
            try:
                with open(self.cache_file, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except Exception:
                self._data = {}
        return self._data

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            tmp = self.cache_file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False)
            os.replace(tmp, self.cache_file)
        except Exception as e:
            self.log("cache vod: %s" % e)

    def _cached(self, key, builder, force=False):
        with _lock:
            data = self._load()
            entry = data.get(key)
            if entry and not force and time.time() - entry.get("time", 0) < CACHE_MAX_AGE:
                return entry["value"]
        try:
            value = builder()
        except Exception as e:
            self.log("vod %s: %s" % (key, e))
            if entry:
                return entry["value"]  # meglio i dati vecchi che niente
            raise
        with _lock:
            self._load()[key] = {"time": time.time(), "value": value}
            self._save()
        return value

    def clear(self):
        with _lock:
            self._data = {}
            self._save()

    # ------------------------------------------------------------ dati
    def series(self, genre, force=False):
        """Serie di un genere: [{id, title, image, season}]."""
        def build():
            page = fetch(BASE + "emissions.aspx?type=%s" % genre)
            out, seen = [], set()
            for m in re.finditer(r'<a[^>]+href="emission\.aspx\?id=(\d+)"[^>]*>(.*?)</a>', page, re.S):
                sid, inner = m.group(1), m.group(2)
                img = re.search(r'src="([^"]+)"', inner)
                title = _clean(inner)
                s = next((x for x in out if x["id"] == sid), None)
                if s is None:
                    if sid in seen:
                        continue
                    seen.add(sid)
                    s = {"id": sid, "title": "", "image": ""}
                    out.append(s)
                if img and not s["image"]:
                    s["image"] = img.group(1)
                if title and not s["title"]:
                    s["title"] = title
            for s in out:
                s["season"] = _season(s["title"])
            return out
        return self._cached("genre:%s" % genre, build, force)

    def genres(self, force=False):
        """[(type, nome, n_serie)] solo per i generi che hanno contenuti."""
        out = []
        for gid, name in GENRES:
            try:
                n = len(self.series(gid, force))
            except Exception:
                n = 0
            if n:
                out.append((gid, name, n))
        return out

    def episodes(self, sid, force=False):
        """Serie ed episodi: {title, image, episodes: [{id, title, number, image}]}."""
        def build():
            page = fetch(BASE + "emission.aspx?id=%s" % sid)
            m = re.search(r'class="titre_emission">([^<]*)', page)
            title = _clean(m.group(1)) if m else ""
            m = re.search(r'og:image" content="([^"]*)"', page)
            image = m.group(1) if m else ""
            eps = []
            for m in re.finditer(r'<div class="episode">\s*<a href="video\.aspx\?id=(\d+)">(.*?)</div>\s*</div>',
                                 page, re.S):
                vid, inner = m.group(1), m.group(2)
                img = re.search(r'src="([^"]+)"', inner)
                t = re.search(r'class="titre-episode"\s*><a[^>]*>([^<]*)</a>', inner)
                ep_title = _clean(t.group(1)) if t else ""
                eps.append({"id": vid, "title": ep_title, "number": _episode_number(ep_title),
                            "image": img.group(1).split("?")[0] if img else ""})
            return {"title": title, "image": image, "season": _season(title), "episodes": eps}
        return self._cached("series:%s" % sid, build, force)


def resolve(video_id):
    """URL MP4 dell'episodio video.aspx?id=<video_id>."""
    page = fetch(BASE + "video.aspx?id=%s" % video_id)
    m = re.search(r'src="(?:\.\./embed/|/embed/|https?://medi1tv\.com/embed/)(video-ashamil\.aspx\?[^"]+)"', page)
    if not m:
        raise RuntimeError("player non trovato per il video %s" % video_id)
    embed = fetch(EMBED_BASE + html.unescape(m.group(1)), {"Referer": BASE + "video.aspx?id=%s" % video_id})
    m = re.search(r"cheminhttp\s*=\s*['\"]([^'\"]+)['\"]", embed)
    if not m:
        raise RuntimeError("file video non trovato per il video %s" % video_id)
    url = m.group(1)
    return "https:" + url if url.startswith("//") else url
