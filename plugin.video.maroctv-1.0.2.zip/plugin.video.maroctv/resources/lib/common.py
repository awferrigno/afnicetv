# -*- coding: utf-8 -*-
import os
import threading
import urllib.request

import xbmc
import xbmcaddon
import xbmcvfs

import proxy
import sources
import vod

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE, "channels.json")
MEDIA = os.path.join(ADDON_PATH, "resources", "media")
ICON = os.path.join(ADDON_PATH, "icon.png")
FANART = os.path.join(ADDON_PATH, "fanart.jpg")
HOST = "127.0.0.1"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


def setting_int(key, default):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def proxy_port():
    return setting_int("proxy_port", 52888)


def include_iptv():
    return ADDON.getSetting("include_iptv") != "false"


def load_channels(force=False, progress=None):
    """(canali, report); report è None se la lista viene dalla cache."""
    return sources.load_channels(CACHE_FILE, force=force, log=log, progress=progress,
                                 include_iptv=include_iptv())


CATALOG = vod.Catalog(os.path.join(PROFILE, "vod.json"), log=log)


def set_channel_ok(cid, ok):
    return sources.set_channel_ok(CACHE_FILE, cid, ok)


def logo_for(ch):
    local = os.path.join(MEDIA, "channels", ch["id"] + ".png")
    if os.path.exists(local):
        return local
    return ch.get("logo") or ICON


class ChannelIndex(object):
    """Mappa id -> canale per il proxy, ricaricata se arriva un id sconosciuto."""

    def __init__(self):
        self._lock = threading.Lock()
        self._map = {}
        self._mtime = None

    def get(self, cid):
        with self._lock:
            try:
                mtime = os.path.getmtime(CACHE_FILE)
            except OSError:
                mtime = None
            if cid not in self._map or mtime != self._mtime:  # lista aggiornata dal plugin
                self._mtime = mtime
                try:
                    self._map = {c["id"]: c for c in load_channels()[0]}
                except Exception as e:
                    log("caricamento canali: %s" % e, xbmc.LOGERROR)
            return self._map.get(cid)


def start_proxy(port):
    return proxy.start(HOST, port, ChannelIndex().get, log=log, version=ADDON_VERSION)


def proxy_alive(port, timeout=2):
    try:
        with urllib.request.urlopen("http://%s:%d/ping" % (HOST, port), timeout=timeout) as r:
            # un proxy di un'altra versione (servizio non ancora riavviato) non va bene
            return r.read().decode("utf-8", "replace").strip() == "maroctv %s" % ADDON_VERSION
    except Exception:
        return False


def proxy_reset(port):
    try:
        urllib.request.urlopen("http://%s:%d/reset" % (HOST, port), timeout=2).close()
    except Exception:
        pass
