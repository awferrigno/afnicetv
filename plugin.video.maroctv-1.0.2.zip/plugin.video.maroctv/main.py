# -*- coding: utf-8 -*-
"""MarocTV: elenco dei canali SNRT e riproduzione con nuovi tentativi automatici."""
import os
import re
import sys
import time
import urllib.parse
import uuid

import xbmcaddon
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath(
    xbmcaddon.Addon().getAddonInfo("path")), "resources", "lib"))

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcplugin  # noqa: E402

import common  # noqa: E402
from common import ADDON_NAME, FANART, ICON, log  # noqa: E402

BASE = "plugin://%s/" % common.ADDON_ID
HANDLE = int(sys.argv[1])
PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))

GROUP_LABEL = {"tv": "TV", "radio": "Radio"}
MENU = os.path.join(common.MEDIA, "menu")


def plugin_url(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)


def notify(msg, icon=ICON, ms=3000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)


def menu_icon(name):
    return os.path.join(MENU, name + ".png")


def make_item(ch, path=None):
    logo = common.logo_for(ch)
    label = ch["name"]
    if ch.get("ok") is False and not path:
        label += " [COLOR gray](non funzionante)[/COLOR]"
    li = xbmcgui.ListItem(label=label, label2=ch.get("source", ""), path=path or "")
    li.setArt({"thumb": logo, "icon": logo, "poster": logo, "fanart": FANART})
    plot = "%s · %s in diretta" % (ch.get("source", ""), GROUP_LABEL.get(ch["group"], ""))
    try:  # Kodi 20+
        tag = li.getVideoInfoTag()
        tag.setTitle(ch["name"])
        tag.setPlot(plot)
        tag.setGenres([GROUP_LABEL.get(ch["group"], "")])
        tag.setStudios([ch.get("source", "")])
        tag.setMediaType("video")
    except AttributeError:  # Kodi 19
        li.setInfo("video", {"title": ch["name"], "plot": plot, "studio": ch.get("source", ""),
                             "genre": GROUP_LABEL.get(ch["group"], ""), "mediatype": "video"})
    return li


def action_item(label, icon, url, plot=""):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": icon, "icon": icon, "fanart": FANART})
    if plot:
        try:
            li.getVideoInfoTag().setPlot(plot)
        except AttributeError:
            li.setInfo("video", {"plot": plot})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


# ---------------------------------------------------------------- caricamento canali

def get_channels(force=False):
    """Canali dalla cache; se serve interrogare le fonti mostra una finestra di avanzamento."""
    dialog = {}

    def progress(pct, msg):
        if "d" not in dialog:
            dialog["d"] = xbmcgui.DialogProgress()
            dialog["d"].create(ADDON_NAME, "Aggiornamento canali in corso…")
        dialog["d"].update(min(100, max(0, pct)), "Aggiornamento canali in corso…\n%s" % msg)
        return dialog["d"].iscanceled()

    try:
        channels, report = common.load_channels(force=force, progress=progress)
    except KeyboardInterrupt:  # annullato dall'utente
        channels, report = None, None
    except Exception as e:
        log("impossibile caricare i canali: %s" % e, xbmc.LOGERROR)
        notify("Impossibile caricare i canali", xbmcgui.NOTIFICATION_ERROR)
        channels, report = [], None
    finally:
        if "d" in dialog:
            dialog["d"].close()
    return channels, report


# ---------------------------------------------------------------- menu

def root_menu():
    channels, _ = get_channels()
    if channels is None:  # aggiornamento annullato: usa quello che c'è in cache
        channels = []
    tv = sum(1 for c in channels if c["group"] == "tv")
    radio = sum(1 for c in channels if c["group"] == "radio")

    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "files")
    action_item("Esci", menu_icon("exit"), plugin_url(action="exit"), "Chiudi MarocTV")
    for group, label, icon in (("tv", "Canali TV", "tv"), ("radio", "Radio", "radio")):
        n = tv if group == "tv" else radio
        li = xbmcgui.ListItem(label="%s (%d)" % (label, n))
        li.setArt({"thumb": menu_icon(icon), "icon": menu_icon(icon), "fanart": FANART})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="list", group=group), li, isFolder=True)
    li = xbmcgui.ListItem(label="Serie TV")
    li.setArt({"thumb": menu_icon("series"), "icon": menu_icon("series"), "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="vod"), li, isFolder=True)
    action_item("Aggiorna canali", menu_icon("refresh"), plugin_url(action="refresh"),
                "Riscarica l'elenco dei canali da tutte le fonti")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def back_item(to=None, plot="Torna al menu principale"):
    action_item("Indietro", menu_icon("back"), plugin_url(action="back", to=to or BASE), plot)


def list_channels(group):
    channels, _ = get_channels()
    xbmcplugin.setPluginCategory(HANDLE, "Canali TV" if group == "tv" else "Radio")
    xbmcplugin.setContent(HANDLE, "videos")
    back_item()
    refresh = [("Aggiorna canali", "RunPlugin(%s)" % plugin_url(action="refresh"))]
    for ch in channels or []:
        if ch["group"] != group:
            continue
        li = make_item(ch)
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(refresh)
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="play", id=ch["id"]), li, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def refresh_channels():
    channels, report = get_channels(force=True)
    if channels is None:
        notify("Aggiornamento annullato")
        return
    tv = sum(1 for c in channels if c["group"] == "tv")
    radio = sum(1 for c in channels if c["group"] == "radio")
    failed = [label for label, _, ok in (report or []) if not ok]
    if failed:
        notify("TV %d · Radio %d (non aggiornate: %s)" % (tv, radio, ", ".join(failed)),
               xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Canali aggiornati: TV %d · Radio %d" % (tv, radio))
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------- serie TV (Medi1 ashamil)

def series_label(title, season):
    if season:
        title = re.sub(r"\s*[ـ\-–]?\s*الموسم\s+\S+", "", title).strip()
        return "%s · Stagione %d" % (title, season)
    return title


def episode_label(title, index):
    m = re.search(r"الحلقة\s*(\d+)", title)
    if not m:
        return title or "Episodio %d" % index
    rest = re.sub(r"\s*[\-–ـ]?\s*الحلقة\s*\d+\s*[\-–ـ]?\s*", " ", title).strip()
    return "%s · Episodio %s" % (rest, m.group(1)) if rest else "Episodio %s" % m.group(1)


def catalog_error(e):
    log("catalogo serie: %s" % e, xbmc.LOGERROR)
    notify("Catalogo Serie TV non disponibile", xbmcgui.NOTIFICATION_ERROR)


def vod_genres():
    xbmcplugin.setPluginCategory(HANDLE, "Serie TV")
    xbmcplugin.setContent(HANDLE, "files")
    back_item()
    try:
        genres = common.CATALOG.genres()
    except Exception as e:
        catalog_error(e)
        genres = []
    for gid, name, n in genres:
        li = xbmcgui.ListItem(label="%s (%d)" % (name, n))
        li.setArt({"thumb": menu_icon("series"), "icon": menu_icon("series"), "fanart": FANART})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="vod_series", genre=gid), li, isFolder=True)
    action_item("Aggiorna catalogo", menu_icon("refresh"), plugin_url(action="vod_refresh"),
                "Riscarica serie ed episodi da Medi1 TV")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def vod_series(genre):
    name = dict(common.vod.GENRES).get(genre, "Serie TV")
    xbmcplugin.setPluginCategory(HANDLE, name)
    xbmcplugin.setContent(HANDLE, "tvshows")
    back_item(plugin_url(action="vod"), "Torna ai generi")
    try:
        series = common.CATALOG.series(genre)
    except Exception as e:
        catalog_error(e)
        series = []
    for s in series:
        label = series_label(s["title"], s.get("season"))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": s["image"], "poster": s["image"], "icon": s["image"],
                   "fanart": s["image"] or FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setTvShowTitle(label)
            tag.setGenres([name])
            tag.setStudios(["Medi1 TV"])
            tag.setMediaType("tvshow")
        except AttributeError:
            li.setInfo("video", {"title": label, "tvshowtitle": label, "genre": name,
                                 "studio": "Medi1 TV", "mediatype": "tvshow"})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="vod_episodes", sid=s["id"], genre=genre),
                                    li, isFolder=True)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def vod_episodes(sid, genre):
    try:
        data = common.CATALOG.episodes(sid)
    except Exception as e:
        catalog_error(e)
        data = {"title": "", "image": "", "season": None, "episodes": []}
    show = series_label(data["title"], data.get("season"))
    xbmcplugin.setPluginCategory(HANDLE, show or "Episodi")
    xbmcplugin.setContent(HANDLE, "episodes")
    back_item(plugin_url(action="vod_series", genre=genre), "Torna alle serie")
    for i, ep in enumerate(data["episodes"], 1):
        li, _ = vod_item(data, ep, i)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="vod_play", vid=ep["id"], sid=sid, n=i),
                                    li, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def vod_refresh():
    dialog = xbmcgui.DialogProgress()
    head = "Aggiornamento catalogo Serie TV in corso…"
    dialog.create(ADDON_NAME, head)
    try:
        common.CATALOG.clear()
        titles = []
        for i, (gid, name) in enumerate(common.vod.GENRES):
            dialog.update(int(40 * i / len(common.vod.GENRES)), "%s\nGenere: %s" % (head, name))
            if dialog.iscanceled():
                raise KeyboardInterrupt
            for s in common.CATALOG.series(gid, force=True):
                if s["id"] not in [x["id"] for x in titles]:
                    titles.append(s)
        for i, s in enumerate(titles):
            dialog.update(40 + int(60 * i / max(1, len(titles))),
                          "%s\n%s" % (head, series_label(s["title"], s.get("season"))))
            if dialog.iscanceled():
                raise KeyboardInterrupt
            try:
                common.CATALOG.episodes(s["id"], force=True)
            except Exception as e:
                log("episodi %s: %s" % (s["id"], e), xbmc.LOGWARNING)
        dialog.update(100, "Completato")
        notify("Catalogo aggiornato: %d titoli" % len(titles))
    except KeyboardInterrupt:
        notify("Aggiornamento annullato")
    except Exception as e:
        catalog_error(e)
    finally:
        dialog.close()
    xbmc.executebuiltin("Container.Refresh")


def vod_item(data, ep, n, url=None):
    show = series_label(data.get("title", ""), data.get("season"))
    label = episode_label(ep.get("title", ""), n)
    li = xbmcgui.ListItem(label=label, path=url or "")
    thumb = ep.get("image") or data.get("image", "")
    li.setArt({"thumb": thumb, "icon": thumb, "poster": data.get("image", ""),
               "fanart": data.get("image") or FANART})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(label)
        tag.setTvShowTitle(show)
        tag.setEpisode(n)
        if data.get("season"):
            tag.setSeason(data["season"])
        tag.setStudios(["Medi1 TV"])
        tag.setMediaType("episode")
    except AttributeError:
        li.setInfo("video", {"title": label, "tvshowtitle": show, "episode": n,
                             "season": data.get("season") or 0, "mediatype": "episode"})
    if url:
        li.setMimeType("video/mp4")
        li.setContentLookup(False)
    return li, ("%s - %s" % (show, label) if show else label)


def episode_data(sid, n):
    try:
        data = common.CATALOG.episodes(sid)
        ep = data["episodes"][n - 1] if 0 < n <= len(data["episodes"]) else {}
    except Exception:
        data, ep = {"title": "", "image": "", "season": None}, {}
    return data, ep


def with_session(url, session):
    return url + ("&" if "?" in url else "?") + "s=" + session


def vod_play(vid, sid, n):
    try:
        base_url = common.vod.resolve(vid)
    except Exception as e:
        log("episodio %s: %s" % (vid, e), xbmc.LOGERROR)
        notify("Episodio non disponibile", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    data, ep = episode_data(sid, n)
    session = uuid.uuid4().hex
    url = with_session(base_url, session)
    li, name = vod_item(data, ep, n, url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    watch_vod(name, vid, data, ep, n, session)


def watch_vod(name, vid, data, ep, n, session):
    """Episodi: se non partono o si interrompono per errore riprova e riprende dal punto giusto."""
    retries = common.setting_int("retries", 3)
    start_timeout = common.setting_int("start_timeout", 25)
    monitor = xbmc.Monitor()
    player = Watcher(live=False)
    attempt, resume_at = 0, 0.0

    def ours():
        try:
            return player.isPlaying() and session in player.getPlayingFile()
        except RuntimeError:
            return False

    while not monitor.abortRequested():
        res = wait_start(player, monitor, ours, start_timeout)
        if res is None:
            return
        if res:
            if resume_at > 5:
                player.seekTime(resume_at)
            last_t, gone_since, failed = resume_at, None, False
            while not monitor.waitForAbort(1):
                if player.stopped or player.ended:
                    return  # fermato dall'utente o episodio finito
                if not player.isPlaying():
                    if player.failed:
                        failed = True
                        break
                    gone_since = gone_since or time.time()
                    if time.time() - gone_since > 3:
                        return
                    continue
                gone_since = None
                if not ours():
                    return
                try:
                    last_t = player.getTime()
                except RuntimeError:
                    pass
                if attempt and last_t - resume_at > 60:  # riparte bene da un minuto
                    attempt = 0
            if not failed:
                return
            resume_at = last_t

        attempt += 1
        if attempt > retries:
            log("%s: riproduzione fallita dopo %d tentativi" % (name, retries), xbmc.LOGERROR)
            if player.isPlaying():
                player.stop()
            notify("Episodio non disponibile", xbmcgui.NOTIFICATION_ERROR, 5000)
            return
        log("%s: nuovo tentativo %d/%d" % (name, attempt, retries), xbmc.LOGWARNING)
        notify("Nessuna riproduzione, riprovo (%d/%d)" % (attempt, retries))
        if monitor.waitForAbort(2):
            return
        try:
            base_url = common.vod.resolve(vid)
        except Exception as e:
            log("episodio %s: %s" % (vid, e), xbmc.LOGWARNING)
            base_url = None
        if base_url:
            session = uuid.uuid4().hex
            url = with_session(base_url, session)
            li, _ = vod_item(data, ep, n, url)
            player.reset()
            player.play(url, li)


# ---------------------------------------------------------------- riproduzione

class Watcher(xbmc.Player):
    def __init__(self, live=True):
        super(Watcher, self).__init__()
        self.live = live
        self.reset()

    def reset(self):
        self.started = self.failed = self.stopped = self.ended = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackEnded(self):
        self.ended = True
        if self.live:  # una diretta che "finisce" è un errore
            self.failed = True

    def onPlayBackStopped(self):
        self.stopped = True


def wait_start(player, monitor, ours, timeout):
    """True = partito, False = fallito, None = annullato dall'utente."""
    deadline = time.time() + timeout
    saw_stop = False
    while not monitor.waitForAbort(0.5):
        if player.started and ours():
            return True
        if player.stopped:  # può arrivare dall'elemento precedente: lo annoto e continuo
            saw_stop, player.stopped = True, False
        if player.failed and not player.isPlaying():
            return False
        if time.time() > deadline:
            return None if saw_stop and not player.isPlaying() else False
    return None


def stream_url(port, ch, session):
    ext = "" if ch.get("kind") == "stream" else ".m3u8"
    return "http://%s:%d/ch/%s%s?s=%s" % (common.HOST, port, ch["id"], ext, session)


def playable_item(ch, url):
    li = make_item(ch, url)
    li.setMimeType("audio/mpeg" if ch.get("kind") == "stream" else "application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    return li


def play(cid):
    try:
        ch = {c["id"]: c for c in common.load_channels()[0]}.get(cid)
    except Exception as e:
        log("canali: %s" % e, xbmc.LOGERROR)
        ch = None
    if not ch:
        notify("Canale non trovato", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    port, local_srv = common.proxy_port(), None
    if not common.proxy_alive(port):
        # Servizio non attivo (appena installato o porta occupata): proxy in questo processo
        log("proxy del servizio non raggiungibile, ne avvio uno locale", xbmc.LOGWARNING)
        local_srv = common.start_proxy(0)
        port = local_srv.server_port

    session = uuid.uuid4().hex
    url = stream_url(port, ch, session)
    xbmcplugin.setResolvedUrl(HANDLE, True, playable_item(ch, url))
    try:
        watch(ch, port, session)
    finally:
        if local_srv:
            local_srv.shutdown()
            local_srv.server_close()


def watch(ch, port, session):
    """Controlla la riproduzione; se non parte o si blocca riprova, poi chiude il canale."""
    retries = common.setting_int("retries", 3)
    start_timeout = common.setting_int("start_timeout", 25)
    stall_timeout = common.setting_int("stall_timeout", 20)
    monitor = xbmc.Monitor()
    player = Watcher()
    attempt = 0

    def ours():
        try:
            return player.isPlaying() and session in player.getPlayingFile()
        except RuntimeError:
            return False

    def keep_watching():
        """True = da ritentare, False = uscire (utente, cambio canale o chiusura Kodi)."""
        nonlocal attempt
        began = last_change = time.time()
        last_t, gone_since, confirmed = -1.0, None, False
        while not monitor.waitForAbort(1):
            now = time.time()
            if player.stopped:
                return False
            if not player.isPlaying():
                if player.failed:
                    return True
                gone_since = gone_since or now
                if now - gone_since > 3:
                    return True
                continue
            gone_since = None
            if not ours():  # l'utente ha avviato qualcos'altro
                return False
            try:
                t = player.getTime()
            except RuntimeError:
                t = last_t
            if xbmc.getCondVisibility("Player.Paused") or t != last_t:
                last_t, last_change = t, now
            elif now - last_change > stall_timeout:
                log("%s: riproduzione ferma da %ds" % (ch["name"], stall_timeout), xbmc.LOGWARNING)
                return True
            if not confirmed and now - began > 10 and t > 0:
                confirmed = True
                if ch.get("ok") is False and common.set_channel_ok(ch["id"], True):
                    ch["ok"] = True
                    log("%s: di nuovo funzionante" % ch["name"])
            if attempt and now - began > 60:  # stabile da un minuto: si riparte da zero
                attempt = 0
        return False

    while not monitor.abortRequested():
        res = wait_start(player, monitor, ours, start_timeout)
        if res is None:
            return
        if res and not keep_watching():
            return
        if monitor.abortRequested():
            return

        attempt += 1
        if attempt > retries:
            log("%s: riproduzione fallita dopo %d tentativi" % (ch["name"], retries), xbmc.LOGERROR)
            if player.isPlaying():
                player.stop()
            if common.set_channel_ok(ch["id"], False):
                xbmc.executebuiltin("Container.Refresh")  # mostra "(non funzionante)" nell'elenco
            notify("%s non disponibile" % ch["name"], xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        log("%s: nuovo tentativo %d/%d" % (ch["name"], attempt, retries), xbmc.LOGWARNING)
        notify("Nessuna riproduzione, riprovo (%d/%d)" % (attempt, retries), common.logo_for(ch))
        if ours():
            player.stop()
            for _ in range(10):
                if not player.isPlaying() or monitor.waitForAbort(0.5):
                    break
        common.proxy_reset(port)
        if monitor.waitForAbort(2):
            return
        session = uuid.uuid4().hex
        url = stream_url(port, ch, session)
        player.reset()
        player.play(url, playable_item(ch, url))


def router():
    action = PARAMS.get("action")
    if action == "play":
        play(PARAMS.get("id", ""))
    elif action == "list":
        list_channels(PARAMS.get("group", "tv"))
    elif action == "refresh":
        refresh_channels()
    elif action == "vod":
        vod_genres()
    elif action == "vod_series":
        vod_series(PARAMS.get("genre", "1"))
    elif action == "vod_episodes":
        vod_episodes(PARAMS.get("sid", ""), PARAMS.get("genre", "1"))
    elif action == "vod_play":
        vod_play(PARAMS.get("vid", ""), PARAMS.get("sid", ""), int(PARAMS.get("n", "1") or 1))
    elif action == "vod_refresh":
        vod_refresh()
    elif action == "back":
        to = PARAMS.get("to", BASE)
        if not to.startswith(BASE):
            to = BASE
        xbmc.executebuiltin("Container.Update(%s,replace)" % to)
    elif action == "exit":
        xbmc.executebuiltin("ActivateWindow(Home)")
    else:
        root_menu()


if __name__ == "__main__":
    router()
