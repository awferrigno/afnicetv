# -*- coding: utf-8 -*-
"""Proxy locale: rende riproducibili in Kodi gli stream che richiedono token o header.

  GET /ping              -> "maroctv <versione>"
  GET /reset             -> svuota token e URL scelti (usato dai nuovi tentativi)
  GET /ch/<id>[.m3u8]    -> HLS: master riscritta; stream audio: flusso inoltrato
  GET /v/<id>?u=<url>    -> playlist annidata riscritta
  GET /s/<id>?u=<url>    -> segmento inoltrato (solo canali che richiedono header)

I segmenti dei canali senza header vengono scaricati dal player direttamente dal CDN.
Se un canale ha più URL, il proxy usa il primo che risponde.
"""
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from sources import EB_CDN, TokenCache, open_url, rewrite_playlist, with_query

HLS_MIME = "application/vnd.apple.mpegurl"
CHUNK = 64 * 1024


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def _host(url):
    return urllib.parse.urlparse(url).netloc.lower()


def start(host, port, get_channel, log=lambda msg: None, version=""):
    """Avvia il proxy in un thread. get_channel(id) -> dict canale o None.

    Ritorna il server (con .server_port) oppure solleva OSError se la porta è occupata.
    """
    tokens = TokenCache()
    lock = threading.Lock()
    chosen = {}   # id canale -> indice dell'URL che funziona
    allowed = {}  # id canale -> host ammessi per /v e /s

    def token_for(c, url):
        if c.get("token") and url.startswith(EB_CDN):
            try:
                return tokens.get(url)
            except Exception as e:
                log("token %s: %s" % (c["id"], e))
        return ""

    def hosts(c):
        with lock:
            return allowed.setdefault(c["id"], {_host(u) for u in c["urls"]})

    def allow(c, url):
        hosts(c).add(_host(url))

    def master(c):
        """(url master, query token, risposta aperta) sul primo URL che risponde."""
        with lock:
            first = chosen.get(c["id"], 0)
        order = list(range(first, len(c["urls"]))) + list(range(0, first))
        last = None
        for i in order:
            url = c["urls"][i]
            q = token_for(c, url)
            try:
                r = open_url(with_query(url, q), c.get("headers"), timeout=12)
            except Exception as e:
                last = e
                log("%s: %s non risponde (%s)" % (c["id"], url, e))
                continue
            with lock:
                chosen[c["id"]] = i
            return url, q, r
        raise last or RuntimeError("nessun URL")

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def _send(self, body, ctype=HLS_MIME, code=200):
            data = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        def _relay(self, r):
            self.send_response(200)
            self.send_header("Content-Type", r.headers.get("Content-Type", "application/octet-stream"))
            if r.headers.get("Content-Length"):
                self.send_header("Content-Length", r.headers["Content-Length"])
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            if self.command == "HEAD":
                return
            try:
                while True:
                    data = r.read(CHUNK)
                    if not data:
                        break
                    self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass  # il player ha chiuso la connessione
            finally:
                r.close()

        def _playlist(self, c, text, base, q):
            cid = c["id"]
            proxied_segments = bool(c.get("headers"))

            def on_playlist(u):
                allow(c, u)
                return "http://%s:%d/v/%s?u=%s" % (host, self.server.server_port, cid,
                                                   urllib.parse.quote(u, safe=""))

            def on_segment(u):
                if proxied_segments:
                    allow(c, u)
                    return "http://%s:%d/s/%s?u=%s" % (host, self.server.server_port, cid,
                                                       urllib.parse.quote(u, safe=""))
                return with_query(u, q) if q and u.startswith(EB_CDN) else u

            return rewrite_playlist(text, base, on_playlist, on_segment)

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            u = urllib.parse.urlparse(self.path)
            parts = [p for p in u.path.split("/") if p]
            try:
                if parts == ["ping"]:
                    return self._send("maroctv\n", "text/plain")
                if parts == ["reset"]:
                    tokens.clear()
                    with lock:
                        chosen.clear()
                    return self._send("ok\n", "text/plain")

                if len(parts) != 2 or parts[0] not in ("ch", "v", "s"):
                    return self._send("not found\n", "text/plain", 404)
                cid = parts[1].split(".")[0]
                c = get_channel(cid)
                if not c:
                    return self._send("canale sconosciuto\n", "text/plain", 404)

                if parts[0] == "ch":
                    url, q, r = master(c)
                    if c.get("kind") == "stream":
                        return self._relay(r)
                    with r:
                        text = r.read().decode("utf-8", "replace")
                        base = r.geturl()
                    return self._send(self._playlist(c, text, base, q))

                target = urllib.parse.parse_qs(u.query).get("u", [""])[0]
                if not target.startswith(("http://", "https://")) or _host(target) not in hosts(c):
                    return self._send("richiesta non valida\n", "text/plain", 400)
                with lock:
                    cur = c["urls"][chosen.get(c["id"], 0)]
                q = token_for(c, cur) if target.startswith(EB_CDN) else ""

                if parts[0] == "s":
                    return self._relay(open_url(target, c.get("headers"), timeout=20))

                try:
                    r = open_url(with_query(target, q), c.get("headers"), timeout=12)
                except Exception:
                    if not q:
                        raise
                    tokens.clear()  # token forse revocato: secondo tentativo con uno nuovo
                    q = token_for(c, cur)
                    r = open_url(with_query(target, q), c.get("headers"), timeout=12)
                with r:
                    text = r.read().decode("utf-8", "replace")
                    base = r.geturl()
                return self._send(self._playlist(c, text, base, q))
            except Exception as e:
                log("proxy %s: %s" % (self.path[:120], e))
                try:
                    self._send("errore: %s\n" % e, "text/plain", 502)
                except Exception:
                    pass

        def log_message(self, fmt, *args):
            pass

    srv = _Server((host, port), Handler)
    t = threading.Thread(target=srv.serve_forever, name="MarocTV-proxy")
    t.daemon = True
    t.start()
    log("proxy avviato su %s:%d" % (host, srv.server_port))
    return srv
