# -*- coding: utf-8 -*-
"""Fonti dei canali MarocTV. Non dipende da Kodi, così si può testare anche fuori.

Ogni canale è un dict:
  id, name, group ('tv'|'radio'), source (etichetta della fonte),
  kind ('hls' | 'stream'), urls (lista, il primo che funziona vince),
  token (True = token Easybroadcast), headers (dict), logo (URL remoto o "")
"""
import html
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/128.0 Safari/537.36")
EB_API = "https://snrt.player.easybroadcast.io/api/events/{slug}"
EB_TOKEN = "https://token.easybroadcast.io/all?url={url}"
EB_CDN = "https://cdn.live.easybroadcast.io/"
CACHE_VERSION = 2
CHANNELS_MAX_AGE = 6 * 3600


def open_url(url, headers=None, timeout=15):
    h = {"User-Agent": UA}
    h.update(headers or {})
    return urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout)


def fetch(url, headers=None, timeout=15):
    with open_url(url, headers, timeout) as r:
        return r.read().decode("utf-8-sig", "replace")


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def _title(s):
    return " ".join(w.capitalize() for w in re.split(r"[_\-\s]+", s) if w)


def _channel(cid, name, group, source, urls, kind="hls", token=False, headers=None, logo=""):
    if isinstance(urls, str):
        urls = [urls]
    return {"id": cid, "name": name, "group": group, "source": source, "kind": kind,
            "urls": [u for u in urls if u], "token": token, "headers": headers or {}, "logo": logo}


def _eb_event(slug):
    ev = json.loads(fetch(EB_API.format(slug=slug)))
    return ev.get("stream_no_timeshift") or ev.get("stream"), ev


# ---------------------------------------------------------------- SNRT

SNRT = "https://snrtlive.ma"


def src_snrt(step):
    start = fetch(SNRT + "/fr/al-aoula", {"Referer": SNRT + "/"})
    pages = sorted(set(re.findall(
        r'href="(?:https?://(?:www\.)?snrtlive\.ma)?(/fr/[a-z0-9\-]+)"', start)))
    out, seen = [], set()

    def add(ch):
        if ch["urls"] and ch["urls"][0] not in seen:
            seen.add(ch["urls"][0])
            out.append(ch)

    for i, path in enumerate(pages):
        page_id = path.split("/")[-1]
        step("SNRT: %s" % _title(page_id), i / float(len(pages)))
        try:
            page = start if path == "/fr/al-aoula" else fetch(SNRT + path, {"Referer": SNRT + "/"})
        except Exception:
            continue
        m = re.search(r"<title>([^<|]+)", page)
        title = html.unescape(m.group(1)).strip() if m else _title(page_id)

        for slug in re.findall(r'player\.easybroadcast\.io/events/([A-Za-z0-9_\-]+)', page):
            try:
                url, _ = _eb_event(slug)
                add(_channel(page_id, title, "tv", "SNRT", url, token=True))
            except Exception:
                pass

        for js in re.findall(r'src="((?:https?:)?//libs\.easybroadcast\.io/[^"]+\.js)"', page):
            js = "https:" + js if js.startswith("//") else js
            try:
                urls = sorted(set(re.findall(
                    r'https://cdn\.live\.easybroadcast\.io/[^"\'\s]+?\.m3u8', fetch(js))))
            except Exception:
                continue
            for url in urls:
                if len(urls) == 1:
                    add(_channel(page_id, title, "radio", "SNRT", url, token=True))
                else:  # radio regionali: tutte nello stesso script
                    stream = url.rstrip("/").split("/")[-2]
                    add(_channel(stream.replace("_", "-"), _title(stream), "radio", "SNRT", url, token=True))
    return out


# ---------------------------------------------------------------- Medi1

MEDI1TV = "https://www.medi1tv.ma/live/live.aspx"
MEDI1_API = "https://idara.medi1tv.ma/rss/medi1radio/"
MEDI1_WEBRADIO = "https://cdn.live.easybroadcast.io/medi1radio/"
# Evento Easybroadcast della diretta Maghreb (quello del sito a volte non è raggiungibile)
MEDI1_RADIO_EB = {"0": "83_medi1radio-maghreb_8s9i4bn"}


def src_medi1tv(step):
    step("Medi1 TV", 0)
    page = html.unescape(fetch(MEDI1TV).replace("&q;", '"'))
    out, seen = [], set()
    for title, slug in re.findall(
            r'"titre":"([^"]+)","link":"https://[a-z0-9.]*player\.easybroadcast\.io/events/([A-Za-z0-9_\-]+)"', page):
        if slug in seen:
            continue
        seen.add(slug)
        try:
            url, _ = _eb_event(slug)
        except Exception:
            url = EB_CDN + "abr_corp/%s/playlist.m3u8" % slug
        name = re.sub(r"(?i)^medi1\s*tv", "Medi1 TV", title).strip()
        cid = "medi1tv-" + _slug(re.sub(r"(?i)^medi1\s*tv", "", title))
        out.append(_channel(cid, name, "tv", "Medi1", url, token=True))
    return out


def src_medi1radio(step):
    out = []
    step("Medi1 Radio: dirette", 0)
    try:
        for r in json.loads(fetch(MEDI1_API + "live.aspx?lg=fr")):
            urls = []
            slug = MEDI1_RADIO_EB.get(r.get("type"))
            if slug:
                try:
                    urls.append(_eb_event(slug)[0])
                except Exception:
                    pass
            for k in ("link", "secours"):
                if r.get(k):
                    urls.append("https:" + r[k] if r[k].startswith("//") else r[k])
            name = r.get("titre", "Medi1 Radio").replace("Medi1 ", "Medi1 Radio ")
            out.append(_channel("medi1-radio-" + _slug(name.split()[-1]), name, "radio", "Medi1", urls,
                                token=any(u.startswith(EB_CDN) for u in urls)))
    except Exception:
        pass
    step("Medi1 Radio: webradio", 0.5)
    try:
        for w in json.loads(fetch(MEDI1_API + "webradios-home.aspx?lg=fr")):
            link = w.get("link")
            if link:
                out.append(_channel("medi1-web-" + _slug(link), "Medi1 %s" % w.get("titre", link), "radio",
                                    "Medi1 Webradio", MEDI1_WEBRADIO + urllib.parse.quote(link), kind="stream",
                                    logo=w.get("image", "")))
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- 2M

RADIO2M_API = "https://bo.radio2m.ma/api/live"
GLOBECAST = "https://cdn-globecast.akamaized.net"
RADIO2M_HEADERS = {"Referer": "https://radio2m.ma/", "Origin": "https://radio2m.ma"}


def src_2m(step):
    step("2M", 0)
    d = json.loads(fetch(RADIO2M_API, RADIO2M_HEADERS))["data"]["data"]
    out = []
    if d.get("link_regarder"):
        out.append(_channel("2m-monde", "2M Monde", "tv", "2M", GLOBECAST + d["link_regarder"],
                            headers=RADIO2M_HEADERS))
    if d.get("link_ecouter"):
        out.append(_channel("radio-2m", "Radio 2M", "radio", "2M", GLOBECAST + d["link_ecouter"],
                            headers=RADIO2M_HEADERS))
    return out


# ---------------------------------------------------------------- iptv-org

IPTV_ORG = "https://iptv-org.github.io/iptv/countries/ma.m3u"


def src_iptv(step):
    step("iptv-org", 0)
    out, attrs = [], None
    for line in fetch(IPTV_ORG).splitlines():
        line = line.strip()
        if line.startswith("#EXTINF"):
            attrs = dict(re.findall(r'([a-z\-]+)="([^"]*)"', line))
            attrs["name"] = line.rsplit(",", 1)[-1].strip()
            attrs["headers"] = {}
            if attrs.get("http-referrer"):
                attrs["headers"]["Referer"] = attrs["http-referrer"]
            if attrs.get("http-user-agent"):
                attrs["headers"]["User-Agent"] = attrs["http-user-agent"]
        elif line.startswith("#EXTVLCOPT:") and attrs is not None:
            k, _, v = line[11:].partition("=")
            if k == "http-referrer":
                attrs["headers"]["Referer"] = v
            elif k == "http-user-agent":
                attrs["headers"]["User-Agent"] = v
        elif line and not line.startswith("#") and attrs is not None:
            name = re.sub(r"\s*(\(\d+p\)|\[[^\]]*\])", "", attrs["name"]).strip()
            tid = attrs.get("tvg-id") or name
            out.append(_channel("iptv-" + _slug(tid), name, "tv", "iptv-org", line,
                                token=line.startswith(EB_CDN), headers=attrs["headers"],
                                logo=attrs.get("tvg-logo", "")))
            attrs = None
    return out


# ---------------------------------------------------------------- raccolta

SOURCES = [
    ("SNRT", src_snrt),
    ("Medi1 TV", src_medi1tv),
    ("Medi1 Radio", src_medi1radio),
    ("2M", src_2m),
    ("iptv-org", src_iptv),
]
SOURCE_ORDER = ["SNRT", "Medi1", "2M", "Medi1 Webradio", "iptv-org"]


def _norm(name):
    return re.sub(r"[^a-z0-9]", "", name.lower())


def discover(progress=None, log=lambda msg: None, include_iptv=True, previous=None):
    """Interroga tutte le fonti. progress(percento, messaggio) -> True per annullare.

    Se una fonte fallisce si tengono i suoi canali della lista precedente.
    """
    sources = [s for s in SOURCES if include_iptv or s[0] != "iptv-org"]
    channels, report = [], []
    for i, (label, fn) in enumerate(sources):
        def step(msg, frac=0.0):
            if progress and progress(int(80 * (i + frac) / len(sources)), msg):
                raise KeyboardInterrupt
        step("Aggiorno %s…" % label)
        try:
            found = fn(step)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            log("fonte %s: %s" % (label, e))
            found = []
        if not found and previous:
            found = [c for c in previous if c.get("_src") == label]
            report.append((label, len(found), False))
        else:
            report.append((label, len(found), True))
        for c in found:
            c["_src"] = label
        channels.extend(found)
    # iptv-org: via i doppioni dei canali ufficiali (stesso nome o stesso URL)
    names = {_norm(c["name"]) for c in channels if c["source"] != "iptv-org"}
    urls = {u for c in channels if c["source"] != "iptv-org" for u in c["urls"]}
    result, ids = [], set()
    for c in channels:
        if c["source"] == "iptv-org" and (_norm(c["name"]) in names or c["urls"][0] in urls):
            continue
        if c["id"] in ids or not c["urls"]:
            continue
        ids.add(c["id"])
        result.append(c)
    result.sort(key=lambda c: (SOURCE_ORDER.index(c["source"]) if c["source"] in SOURCE_ORDER else 99,
                               c["name"].lower()))
    check_all(result, progress)
    if progress:
        progress(100, "Completato")
    return result, report


# ---------------------------------------------------------------- verifica

def check_channel(c, tokens=None, timeout=8):
    """True se almeno uno degli URL del canale risponde con dati riproducibili."""
    tokens = tokens or TokenCache()
    for url in c["urls"]:
        try:
            q = tokens.get(url) if c.get("token") and url.startswith(EB_CDN) else ""
            with open_url(with_query(url, q), c.get("headers"), timeout) as r:
                if c.get("kind") == "stream":
                    if r.read(1024):
                        return True
                    continue
                text = r.read().decode("utf-8", "replace")
                base = r.geturl()
            if "#EXTM3U" not in text:
                continue
            nested = []
            rewrite_playlist(text, base, lambda u: nested.append(u) or u, lambda u: u)
            if not nested:
                return True  # playlist media: ha già i segmenti
            with open_url(with_query(nested[0], q if nested[0].startswith(EB_CDN) else ""),
                          c.get("headers"), timeout) as r:
                if "#EXTM3U" in r.read().decode("utf-8", "replace"):
                    return True
        except Exception:
            continue
    return False


def check_all(channels, progress=None, workers=10):
    """Imposta c["ok"] su ogni canale, controllandoli in parallelo."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    tokens = TokenCache()
    done = 0
    with ThreadPoolExecutor(workers) as ex:
        futures = {ex.submit(check_channel, c, tokens): c for c in channels}
        for f in as_completed(futures):
            c = futures[f]
            try:
                c["ok"] = bool(f.result())
            except Exception:
                c["ok"] = False
            done += 1
            if progress and progress(80 + int(20 * done / max(1, len(channels))),
                                     "Verifica canali %d/%d: %s" % (done, len(channels), c["name"])):
                for other in futures:
                    other.cancel()
                raise KeyboardInterrupt


def set_channel_ok(cache_file, cid, ok):
    """Aggiorna lo stato funzionante/non funzionante di un canale nella cache."""
    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        changed = False
        for c in data.get("channels", []):
            if c["id"] == cid and c.get("ok") != ok:
                c["ok"], changed = ok, True
        if changed:
            tmp = cache_file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp, cache_file)
        return changed
    except Exception:
        return False


def load_channels(cache_file, force=False, log=lambda msg: None, progress=None, include_iptv=True):
    """Canali dalla cache su disco; riscoperti se vecchi, mancanti o con force=True.

    Ritorna (canali, report) dove report è [(fonte, n, aggiornata)] o None se dalla cache.
    """
    cached = None
    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            cached = json.load(f)
        if cached.get("version") != CACHE_VERSION or cached.get("iptv", True) != include_iptv:
            cached = dict(cached, time=0)
    except Exception:
        cached = None
    if cached and cached.get("version") == CACHE_VERSION and not force \
            and time.time() - cached.get("time", 0) < CHANNELS_MAX_AGE:
        return cached["channels"], None
    previous = cached["channels"] if cached and cached.get("version") == CACHE_VERSION else None
    channels, report = discover(progress, log, include_iptv, previous)
    if not channels:
        if previous:
            return previous, report
        raise RuntimeError("nessun canale trovato")
    try:
        os.makedirs(os.path.dirname(cache_file), exist_ok=True)
        tmp = cache_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"version": CACHE_VERSION, "time": time.time(), "iptv": include_iptv,
                       "channels": channels}, f, ensure_ascii=False)
        os.replace(tmp, cache_file)
    except Exception as e:
        log("scrittura cache: %s" % e)
    return channels, report


# ---------------------------------------------------------------- token + HLS

class TokenCache(object):
    """Token Easybroadcast per URL master, rinnovato 2 minuti prima della scadenza."""

    def __init__(self):
        self._lock = threading.Lock()
        self._cache = {}

    def get(self, url):
        with self._lock:
            q, exp = self._cache.get(url, (None, 0))
            if q and exp - time.time() > 120:
                return q
        q = fetch(EB_TOKEN.format(url=urllib.parse.quote(url, safe=""))).strip()
        if "token=" not in q:
            raise RuntimeError("risposta token non valida: %r" % q[:100])
        try:
            exp = int(urllib.parse.parse_qs(q)["expires"][0])
        except Exception:
            exp = time.time() + 600
        with self._lock:
            self._cache[url] = (q, exp)
        return q

    def clear(self):
        with self._lock:
            self._cache.clear()


def with_query(url, q):
    if not q:
        return url
    return url + ("&" if "?" in url else "?") + q


def rewrite_playlist(text, base, on_playlist, on_segment):
    """Riscrive gli URI della playlist: playlist annidate e segmenti hanno callback diverse."""
    out, next_is_playlist = [], False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#EXT-X-STREAM-INF"):
            next_is_playlist = True
        elif s and not s.startswith("#"):
            u = urllib.parse.urljoin(base, s)
            is_pl = next_is_playlist or urllib.parse.urlparse(u).path.endswith(".m3u8")
            line = on_playlist(u) if is_pl else on_segment(u)
            next_is_playlist = False
        elif 'URI="' in s:
            is_media = s.startswith("#EXT-X-MEDIA:") or s.startswith("#EXT-X-I-FRAME-STREAM-INF")
            line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % (
                on_playlist if is_media else on_segment)(urllib.parse.urljoin(base, m.group(1))), line)
        out.append(line)
    return "\n".join(out) + "\n"
