# -*- coding: utf-8 -*-
"""MarocTV: elenco dei canali SNRT e riproduzione con nuovi tentativi automatici."""
import os
import sys
import time
import urllib.parse
import uuid

import xbmcaddon
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath(
    xbmcaddon.Addon().getAddonInfo("path")), "resources", "lib"))

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcplugin  # noqa: E402

import common  # noqa: E402
from common import ADDON_NAME, FANART, ICON, log  # noqa: E402

BASE = "plugin://%s/" % common.ADDON_ID
HANDLE = int(sys.argv[1])
PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))

GROUP_LABEL = {"tv": "TV", "radio": "Radio"}
MENU = os.path.join(common.MEDIA, "menu")


def plugin_url(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)


def notify(msg, icon=ICON, ms=3000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)


def menu_icon(name):
    return os.path.join(MENU, name + ".png")


def make_item(ch, path=None):
    logo = common.logo_for(ch)
    label = ch["name"]
    if ch.get("ok") is False and not path:
        label += " [COLOR gray](non funzionante)[/COLOR]"
    li = xbmcgui.ListItem(label=label, label2=ch.get("source", ""), path=path or "")
    li.setArt({"thumb": logo, "icon": logo, "poster": logo, "fanart": FANART})
    plot = "%s · %s in diretta" % (ch.get("source", ""), GROUP_LABEL.get(ch["group"], ""))
    try:  # Kodi 20+
        tag = li.getVideoInfoTag()
        tag.setTitle(ch["name"])
        tag.setPlot(plot)
        tag.setGenres([GROUP_LABEL.get(ch["group"], "")])
        tag.setStudios([ch.get("source", "")])
        tag.setMediaType("video")
    except AttributeError:  # Kodi 19
        li.setInfo("video", {"title": ch["name"], "plot": plot, "studio": ch.get("source", ""),
                             "genre": GROUP_LABEL.get(ch["group"], ""), "mediatype": "video"})
    return li


def action_item(label, icon, url, plot=""):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": icon, "icon": icon, "fanart": FANART})
    if plot:
        try:
            li.getVideoInfoTag().setPlot(plot)
        except AttributeError:
            li.setInfo("video", {"plot": plot})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


# ---------------------------------------------------------------- caricamento canali

def get_channels(force=False):
    """Canali dalla cache; se serve interrogare le fonti mostra una finestra di avanzamento."""
    dialog = {}

    def progress(pct, msg):
        if "d" not in dialog:
            dialog["d"] = xbmcgui.DialogProgress()
            dialog["d"].create(ADDON_NAME, "Aggiornamento canali in corso…")
        dialog["d"].update(min(100, max(0, pct)), "Aggiornamento canali in corso…\n%s" % msg)
        return dialog["d"].iscanceled()

    try:
        channels, report = common.load_channels(force=force, progress=progress)
    except KeyboardInterrupt:  # annullato dall'utente
        channels, report = None, None
    except Exception as e:
        log("impossibile caricare i canali: %s" % e, xbmc.LOGERROR)
        notify("Impossibile caricare i canali", xbmcgui.NOTIFICATION_ERROR)
        channels, report = [], None
    finally:
        if "d" in dialog:
            dialog["d"].close()
    return channels, report


# ---------------------------------------------------------------- menu

def root_menu():
    channels, _ = get_channels()
    if channels is None:  # aggiornamento annullato: usa quello che c'è in cache
        channels = []
    tv = sum(1 for c in channels if c["group"] == "tv")
    radio = sum(1 for c in channels if c["group"] == "radio")

    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "files")
    action_item("Esci", menu_icon("exit"), plugin_url(action="exit"), "Chiudi MarocTV")
    for group, label, icon in (("tv", "Canali TV", "tv"), ("radio", "Radio", "radio")):
        n = tv if group == "tv" else radio
        li = xbmcgui.ListItem(label="%s (%d)" % (label, n))
        li.setArt({"thumb": menu_icon(icon), "icon": menu_icon(icon), "fanart": FANART})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="list", group=group), li, isFolder=True)
    action_item("Aggiorna canali", menu_icon("refresh"), plugin_url(action="refresh"),
                "Riscarica l'elenco dei canali da tutte le fonti")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_channels(group):
    channels, _ = get_channels()
    xbmcplugin.setPluginCategory(HANDLE, "Canali TV" if group == "tv" else "Radio")
    xbmcplugin.setContent(HANDLE, "videos")
    action_item("Indietro", menu_icon("back"), plugin_url(action="back"), "Torna al menu principale")
    refresh = [("Aggiorna canali", "RunPlugin(%s)" % plugin_url(action="refresh"))]
    for ch in channels or []:
        if ch["group"] != group:
            continue
        li = make_item(ch)
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(refresh)
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="play", id=ch["id"]), li, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def refresh_channels():
    channels, report = get_channels(force=True)
    if channels is None:
        notify("Aggiornamento annullato")
        return
    tv = sum(1 for c in channels if c["group"] == "tv")
    radio = sum(1 for c in channels if c["group"] == "radio")
    failed = [label for label, _, ok in (report or []) if not ok]
    if failed:
        notify("TV %d · Radio %d (non aggiornate: %s)" % (tv, radio, ", ".join(failed)),
               xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Canali aggiornati: TV %d · Radio %d" % (tv, radio))
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------- riproduzione

class Watcher(xbmc.Player):
    def __init__(self):
        super(Watcher, self).__init__()
        self.reset()

    def reset(self):
        self.started = self.failed = self.stopped = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackEnded(self):  # una diretta che "finisce" è un errore
        self.failed = True

    def onPlayBackStopped(self):
        self.stopped = True


def stream_url(port, ch, session):
    ext = "" if ch.get("kind") == "stream" else ".m3u8"
    return "http://%s:%d/ch/%s%s?s=%s" % (common.HOST, port, ch["id"], ext, session)


def playable_item(ch, url):
    li = make_item(ch, url)
    li.setMimeType("audio/mpeg" if ch.get("kind") == "stream" else "application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    return li


def play(cid):
    try:
        ch = {c["id"]: c for c in common.load_channels()[0]}.get(cid)
    except Exception as e:
        log("canali: %s" % e, xbmc.LOGERROR)
        ch = None
    if not ch:
        notify("Canale non trovato", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    port, local_srv = common.proxy_port(), None
    if not common.proxy_alive(port):
        # Servizio non attivo (appena installato o porta occupata): proxy in questo processo
        log("proxy del servizio non raggiungibile, ne avvio uno locale", xbmc.LOGWARNING)
        local_srv = common.start_proxy(0)
        port = local_srv.server_port

    session = uuid.uuid4().hex
    url = stream_url(port, ch, session)
    xbmcplugin.setResolvedUrl(HANDLE, True, playable_item(ch, url))
    try:
        watch(ch, port, session)
    finally:
        if local_srv:
            local_srv.shutdown()
            local_srv.server_close()


def watch(ch, port, session):
    """Controlla la riproduzione; se non parte o si blocca riprova, poi chiude il canale."""
    retries = common.setting_int("retries", 3)
    start_timeout = common.setting_int("start_timeout", 25)
    stall_timeout = common.setting_int("stall_timeout", 20)
    monitor = xbmc.Monitor()
    player = Watcher()
    attempt = 0

    def ours():
        try:
            return player.isPlaying() and session in player.getPlayingFile()
        except RuntimeError:
            return False

    def wait_start():
        """True = partito, False = fallito, None = annullato dall'utente."""
        deadline = time.time() + start_timeout
        saw_stop = False
        while not monitor.waitForAbort(0.5):
            if player.started and ours():
                return True
            if player.stopped:  # può arrivare dal canale precedente: lo annoto e continuo
                saw_stop, player.stopped = True, False
            if player.failed and not player.isPlaying():
                return False
            if time.time() > deadline:
                return None if saw_stop and not player.isPlaying() else False
        return None

    def keep_watching():
        """True = da ritentare, False = uscire (utente, cambio canale o chiusura Kodi)."""
        nonlocal attempt
        began = last_change = time.time()
        last_t, gone_since, confirmed = -1.0, None, False
        while not monitor.waitForAbort(1):
            now = time.time()
            if player.stopped:
                return False
            if not player.isPlaying():
                if player.failed:
                    return True
                gone_since = gone_since or now
                if now - gone_since > 3:
                    return True
                continue
            gone_since = None
            if not ours():  # l'utente ha avviato qualcos'altro
                return False
            try:
                t = player.getTime()
            except RuntimeError:
                t = last_t
            if xbmc.getCondVisibility("Player.Paused") or t != last_t:
                last_t, last_change = t, now
            elif now - last_change > stall_timeout:
                log("%s: riproduzione ferma da %ds" % (ch["name"], stall_timeout), xbmc.LOGWARNING)
                return True
            if not confirmed and now - began > 10 and t > 0:
                confirmed = True
                if ch.get("ok") is False and common.set_channel_ok(ch["id"], True):
                    ch["ok"] = True
                    log("%s: di nuovo funzionante" % ch["name"])
            if attempt and now - began > 60:  # stabile da un minuto: si riparte da zero
                attempt = 0
        return False

    while not monitor.abortRequested():
        res = wait_start()
        if res is None:
            return
        if res and not keep_watching():
            return
        if monitor.abortRequested():
            return

        attempt += 1
        if attempt > retries:
            log("%s: riproduzione fallita dopo %d tentativi" % (ch["name"], retries), xbmc.LOGERROR)
            if player.isPlaying():
                player.stop()
            if common.set_channel_ok(ch["id"], False):
                xbmc.executebuiltin("Container.Refresh")  # mostra "(non funzionante)" nell'elenco
            notify("%s non disponibile" % ch["name"], xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        log("%s: nuovo tentativo %d/%d" % (ch["name"], attempt, retries), xbmc.LOGWARNING)
        notify("Nessuna riproduzione, riprovo (%d/%d)" % (attempt, retries), common.logo_for(ch))
        if ours():
            player.stop()
            for _ in range(10):
                if not player.isPlaying() or monitor.waitForAbort(0.5):
                    break
        common.proxy_reset(port)
        if monitor.waitForAbort(2):
            return
        session = uuid.uuid4().hex
        url = stream_url(port, ch, session)
        player.reset()
        player.play(url, playable_item(ch, url))


def router():
    action = PARAMS.get("action")
    if action == "play":
        play(PARAMS.get("id", ""))
    elif action == "list":
        list_channels(PARAMS.get("group", "tv"))
    elif action == "refresh":
        refresh_channels()
    elif action == "back":
        xbmc.executebuiltin("Container.Update(%s,replace)" % BASE)
    elif action == "exit":
        xbmc.executebuiltin("ActivateWindow(Home)")
    else:
        root_menu()


if __name__ == "__main__":
    router()
