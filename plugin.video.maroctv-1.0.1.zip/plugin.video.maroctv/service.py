# -*- coding: utf-8 -*-
"""Servizio MarocTV: tiene attivo il proxy HLS locale finché Kodi è aperto."""
import os
import sys

import xbmcaddon
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath(
    xbmcaddon.Addon().getAddonInfo("path")), "resources", "lib"))

import xbmc  # noqa: E402

import common  # noqa: E402


def run():
    monitor = xbmc.Monitor()
    port = common.proxy_port()
    try:
        srv = common.start_proxy(port)
    except OSError as e:
        # Il plugin in quel caso avvia un proxy proprio su una porta libera
        common.log("porta %d non disponibile: %s" % (port, e), xbmc.LOGWARNING)
        return
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    srv.shutdown()
    srv.server_close()
    common.log("proxy fermato")


if __name__ == "__main__":
    run()
