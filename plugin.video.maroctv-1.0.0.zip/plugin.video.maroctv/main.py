# -*- coding: utf-8 -*-
"""MarocTV: elenco dei canali SNRT e riproduzione con nuovi tentativi automatici."""
import os
import sys
import time
import urllib.parse
import uuid

import xbmcaddon
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath(
    xbmcaddon.Addon().getAddonInfo("path")), "resources", "lib"))

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcplugin  # noqa: E402

import common  # noqa: E402
from common import ADDON_NAME, FANART, ICON, log  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))

GROUP_LABEL = {"tv": "TV", "radio": "Radio"}


def plugin_url(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)


def notify(msg, icon=ICON, ms=3000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)


def make_item(ch, path=None):
    logo = common.logo_for(ch)
    li = xbmcgui.ListItem(label=ch["name"], label2=GROUP_LABEL.get(ch["group"], ""), path=path or "")
    li.setArt({"thumb": logo, "icon": logo, "poster": logo, "fanart": FANART})
    plot = "SNRT %s · in diretta" % GROUP_LABEL.get(ch["group"], "")
    try:  # Kodi 20+
        tag = li.getVideoInfoTag()
        tag.setTitle(ch["name"])
        tag.setPlot(plot)
        tag.setGenres([GROUP_LABEL.get(ch["group"], "")])
        tag.setMediaType("video")
    except AttributeError:  # Kodi 19
        li.setInfo("video", {"title": ch["name"], "plot": plot,
                             "genre": GROUP_LABEL.get(ch["group"], ""), "mediatype": "video"})
    return li


# ---------------------------------------------------------------- elenco

def list_channels():
    try:
        channels = common.load_channels()
    except Exception as e:
        log("impossibile caricare i canali: %s" % e, xbmc.LOGERROR)
        notify("Impossibile caricare i canali", xbmcgui.NOTIFICATION_ERROR)
        channels = []

    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "videos")
    refresh = [("Aggiorna lista canali", "RunPlugin(%s)" % plugin_url(action="refresh"))]
    for ch in channels:
        li = make_item(ch)
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems(refresh)
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="play", id=ch["id"]), li, isFolder=False)

    li = xbmcgui.ListItem(label="[I]Aggiorna lista canali[/I]")
    li.setArt({"thumb": ICON, "icon": ICON, "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="refresh"), li, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def refresh_channels():
    try:
        n = len(common.load_channels(force=True))
        notify("%d canali trovati" % n)
    except Exception as e:
        log("aggiornamento canali: %s" % e, xbmc.LOGERROR)
        notify("Aggiornamento non riuscito", xbmcgui.NOTIFICATION_ERROR)
    xbmc.executebuiltin("Container.Refresh")


# ---------------------------------------------------------------- riproduzione

class Watcher(xbmc.Player):
    def __init__(self):
        super(Watcher, self).__init__()
        self.reset()

    def reset(self):
        self.started = self.failed = self.stopped = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackEnded(self):  # una diretta che "finisce" è un errore
        self.failed = True

    def onPlayBackStopped(self):
        self.stopped = True


def stream_url(port, cid, session):
    return "http://%s:%d/ch/%s.m3u8?s=%s" % (common.HOST, port, cid, session)


def playable_item(ch, url):
    li = make_item(ch, url)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    return li


def play(cid):
    try:
        ch = {c["id"]: c for c in common.load_channels()}.get(cid)
    except Exception as e:
        log("canali: %s" % e, xbmc.LOGERROR)
        ch = None
    if not ch:
        notify("Canale non trovato", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    port, local_srv = common.proxy_port(), None
    if not common.proxy_alive(port):
        # Servizio non attivo (appena installato o porta occupata): proxy in questo processo
        log("proxy del servizio non raggiungibile, ne avvio uno locale", xbmc.LOGWARNING)
        local_srv = common.start_proxy(0)
        port = local_srv.server_port

    session = uuid.uuid4().hex
    url = stream_url(port, cid, session)
    xbmcplugin.setResolvedUrl(HANDLE, True, playable_item(ch, url))
    try:
        watch(ch, port, session)
    finally:
        if local_srv:
            local_srv.shutdown()
            local_srv.server_close()


def watch(ch, port, session):
    """Controlla la riproduzione; se non parte o si blocca riprova, poi chiude il canale."""
    retries = common.setting_int("retries", 3)
    start_timeout = common.setting_int("start_timeout", 25)
    stall_timeout = common.setting_int("stall_timeout", 20)
    monitor = xbmc.Monitor()
    player = Watcher()
    attempt = 0

    def ours():
        try:
            return player.isPlaying() and session in player.getPlayingFile()
        except RuntimeError:
            return False

    def wait_start():
        """True = partito, False = fallito, None = annullato dall'utente."""
        deadline = time.time() + start_timeout
        saw_stop = False
        while not monitor.waitForAbort(0.5):
            if player.started and ours():
                return True
            if player.stopped:  # può arrivare dal canale precedente: lo annoto e continuo
                saw_stop, player.stopped = True, False
            if player.failed and not player.isPlaying():
                return False
            if time.time() > deadline:
                return None if saw_stop and not player.isPlaying() else False
        return None

    def keep_watching():
        """True = da ritentare, False = uscire (utente, cambio canale o chiusura Kodi)."""
        nonlocal attempt
        began = last_change = time.time()
        last_t, gone_since = -1.0, None
        while not monitor.waitForAbort(1):
            now = time.time()
            if player.stopped:
                return False
            if not player.isPlaying():
                if player.failed:
                    return True
                gone_since = gone_since or now
                if now - gone_since > 3:
                    return True
                continue
            gone_since = None
            if not ours():  # l'utente ha avviato qualcos'altro
                return False
            try:
                t = player.getTime()
            except RuntimeError:
                t = last_t
            if xbmc.getCondVisibility("Player.Paused") or t != last_t:
                last_t, last_change = t, now
            elif now - last_change > stall_timeout:
                log("%s: riproduzione ferma da %ds" % (ch["name"], stall_timeout), xbmc.LOGWARNING)
                return True
            if attempt and now - began > 60:  # stabile da un minuto: si riparte da zero
                attempt = 0
        return False

    while not monitor.abortRequested():
        res = wait_start()
        if res is None:
            return
        if res and not keep_watching():
            return
        if monitor.abortRequested():
            return

        attempt += 1
        if attempt > retries:
            log("%s: riproduzione fallita dopo %d tentativi" % (ch["name"], retries), xbmc.LOGERROR)
            if player.isPlaying():
                player.stop()
            notify("%s non disponibile" % ch["name"], xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        log("%s: nuovo tentativo %d/%d" % (ch["name"], attempt, retries), xbmc.LOGWARNING)
        notify("Nessuna riproduzione, riprovo (%d/%d)" % (attempt, retries), common.logo_for(ch))
        if ours():
            player.stop()
            for _ in range(10):
                if not player.isPlaying() or monitor.waitForAbort(0.5):
                    break
        common.proxy_reset(port)
        if monitor.waitForAbort(2):
            return
        session = uuid.uuid4().hex
        url = stream_url(port, ch["id"], session)
        player.reset()
        player.play(url, playable_item(ch, url))


def router():
    action = PARAMS.get("action")
    if action == "play":
        play(PARAMS.get("id", ""))
    elif action == "refresh":
        refresh_channels()
    else:
        list_channels()


if __name__ == "__main__":
    router()
