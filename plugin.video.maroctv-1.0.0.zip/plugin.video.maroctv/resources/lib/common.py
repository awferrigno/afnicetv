# -*- coding: utf-8 -*-
import os
import threading
import urllib.request

import xbmc
import xbmcaddon
import xbmcvfs

import proxy
import snrt

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE, "channels.json")
MEDIA = os.path.join(ADDON_PATH, "resources", "media")
ICON = os.path.join(ADDON_PATH, "icon.png")
FANART = os.path.join(ADDON_PATH, "fanart.jpg")
HOST = "127.0.0.1"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


def setting_int(key, default):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def proxy_port():
    return setting_int("proxy_port", 52888)


def load_channels(force=False):
    return snrt.load_channels(CACHE_FILE, force=force, log=log)


def logo_for(ch):
    local = os.path.join(MEDIA, "channels", ch["id"] + ".png")
    if os.path.exists(local):
        return local
    return ch.get("logo") or ICON


class ChannelIndex(object):
    """Mappa id -> canale per il proxy, ricaricata se arriva un id sconosciuto."""

    def __init__(self):
        self._lock = threading.Lock()
        self._map = {}

    def get(self, cid):
        with self._lock:
            if cid not in self._map:
                try:
                    self._map = {c["id"]: c for c in load_channels()}
                except Exception as e:
                    log("caricamento canali: %s" % e, xbmc.LOGERROR)
            return self._map.get(cid)


def start_proxy(port):
    return proxy.start(HOST, port, ChannelIndex().get, log=log)


def proxy_alive(port, timeout=2):
    try:
        with urllib.request.urlopen("http://%s:%d/ping" % (HOST, port), timeout=timeout) as r:
            return r.read().startswith(b"maroctv")
    except Exception:
        return False


def proxy_reset(port):
    try:
        urllib.request.urlopen("http://%s:%d/reset" % (HOST, port), timeout=2).close()
    except Exception:
        pass
