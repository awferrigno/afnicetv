# -*- coding: utf-8 -*-
"""Proxy HLS locale: aggiunge token Easybroadcast sempre validi alle playlist.

  GET /ping              -> "maroctv"
  GET /reset             -> svuota la cache dei token
  GET /ch/<id>.m3u8      -> master playlist con varianti che puntano al proxy
  GET /v/<id>?u=<url>    -> variante con segmenti assoluti sul CDN + token

I segmenti .ts vengono scaricati dal player direttamente dal CDN.
"""
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from snrt import CDN_PREFIX, TokenCache, fetch, rewrite_playlist, with_query

HLS_MIME = "application/vnd.apple.mpegurl"


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def start(host, port, get_channel, log=lambda msg: None):
    """Avvia il proxy in un thread. get_channel(id) -> dict canale o None.

    Ritorna il server (con .server_port) oppure solleva OSError se la porta è occupata.
    """
    tokens = TokenCache()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def _send(self, body, ctype=HLS_MIME, code=200, head=False):
            data = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            if not head:
                self.wfile.write(data)

        def do_HEAD(self):
            self.do_GET(head=True)

        def do_GET(self, head=False):
            u = urllib.parse.urlparse(self.path)
            parts = [p for p in u.path.split("/") if p]
            base = "http://%s:%d" % (host, self.server.server_port)
            try:
                if parts == ["ping"]:
                    return self._send("maroctv\n", "text/plain", head=head)
                if parts == ["reset"]:
                    tokens.clear()
                    return self._send("ok\n", "text/plain", head=head)

                if len(parts) == 2 and parts[0] == "ch":
                    cid = parts[1][:-5] if parts[1].endswith(".m3u8") else parts[1]
                    c = get_channel(cid)
                    if not c:
                        return self._send("canale sconosciuto\n", "text/plain", 404, head)
                    q = tokens.get(c["url"])
                    text = fetch(with_query(c["url"], q))
                    body = rewrite_playlist(text, c["url"], lambda v: "%s/v/%s?u=%s" % (
                        base, cid, urllib.parse.quote(v, safe="")))
                    return self._send(body, head=head)

                if len(parts) == 2 and parts[0] == "v":
                    c = get_channel(parts[1])
                    v = urllib.parse.parse_qs(u.query).get("u", [""])[0]
                    if not c or not v.startswith(CDN_PREFIX):
                        return self._send("richiesta non valida\n", "text/plain", 400, head)
                    q = tokens.get(c["url"])
                    try:
                        text = fetch(with_query(v, q))
                    except Exception:
                        tokens.clear()  # token forse revocato: un secondo tentativo con uno nuovo
                        q = tokens.get(c["url"])
                        text = fetch(with_query(v, q))
                    return self._send(rewrite_playlist(text, v, lambda s: with_query(s, q)), head=head)

                self._send("not found\n", "text/plain", 404, head)
            except Exception as e:
                log("proxy %s: %s" % (self.path, e))
                self._send("errore: %s\n" % e, "text/plain", 502, head)

        def log_message(self, fmt, *args):
            pass

    srv = _Server((host, port), Handler)
    t = threading.Thread(target=srv.serve_forever, name="MarocTV-proxy")
    t.daemon = True
    t.start()
    log("proxy avviato su %s:%d" % (host, srv.server_port))
    return srv
