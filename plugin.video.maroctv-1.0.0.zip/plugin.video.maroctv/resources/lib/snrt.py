# -*- coding: utf-8 -*-
"""Estrazione canali e stream da snrtlive.ma (player Easybroadcast).

Non dipende da Kodi, così si può testare anche fuori.
"""
import html
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

SITE = "https://snrtlive.ma"
START_PAGE = SITE + "/fr/al-aoula"
PLAYER_API = "https://snrt.player.easybroadcast.io/api/events/{slug}"
TOKEN_URL = "https://token.easybroadcast.io/all?url={url}"
CDN_PREFIX = "https://cdn.live.easybroadcast.io/"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/128.0 Safari/537.36")
CHANNELS_MAX_AGE = 6 * 3600


def fetch(url, referer=SITE + "/", timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": referer})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


# ---------------------------------------------------------------- canali

def _slug_to_name(s):
    return " ".join(w.capitalize() for w in re.split(r"[_\-]+", s) if w)


def discover(log=lambda msg: None):
    """Lista di dict: id, name, group ('tv'|'radio'), url (master m3u8 senza token), logo."""
    start = fetch(START_PAGE)
    pages = sorted(set(re.findall(
        r'href="(?:https?://(?:www\.)?snrtlive\.ma)?(/fr/[a-z0-9\-]+)"', start)))
    logos = {k: v for k, v in re.findall(
        r'href="https?://(?:www\.)?snrt(?:live)?\.ma/fr/([a-z0-9\-]+) ?"><img src="([^"]+)"', start)}
    channels, seen = [], set()

    def add(cid, name, group, url, logo=""):
        if url not in seen:
            seen.add(url)
            channels.append({"id": cid, "name": name, "group": group, "url": url, "logo": logo})

    for path in pages:
        page_id = path.split("/")[-1]
        try:
            page = start if SITE + path == START_PAGE else fetch(SITE + path)
        except Exception as e:
            log("pagina %s: %s" % (path, e))
            continue
        m = re.search(r"<title>([^<|]+)", page)
        title = html.unescape(m.group(1)).strip() if m else _slug_to_name(page_id)

        # TV: iframe del player -> API evento
        for slug in re.findall(r'player\.easybroadcast\.io/events/([A-Za-z0-9_\-]+)', page):
            try:
                ev = json.loads(fetch(PLAYER_API.format(slug=slug)))
                url = ev.get("stream_no_timeshift") or ev.get("stream")
                if url:
                    add(page_id, title, "tv", url, logos.get(page_id, ""))
            except Exception as e:
                log("evento %s: %s" % (slug, e))

        # Radio: script libs.easybroadcast.io che contiene gli URL m3u8
        for js in re.findall(r'src="((?:https?:)?//libs\.easybroadcast\.io/[^"]+\.js)"', page):
            if js.startswith("//"):
                js = "https:" + js
            try:
                urls = sorted(set(re.findall(
                    r'https://cdn\.live\.easybroadcast\.io/[^"\'\s]+?\.m3u8', fetch(js))))
            except Exception as e:
                log("script %s: %s" % (js, e))
                continue
            for url in urls:
                if len(urls) == 1:
                    add(page_id, title, "radio", url, logos.get(page_id, ""))
                else:  # uno script con più radio (radio regionali)
                    stream = url.rstrip("/").split("/")[-2]  # radio_agadir
                    add(stream.replace("_", "-"), _slug_to_name(stream), "radio", url)

    channels.sort(key=lambda c: (c["group"] != "tv", c["name"].lower()))
    return channels


def load_channels(cache_file, force=False, log=lambda msg: None):
    """Canali dalla cache su disco; riscoperti se vecchi, mancanti o se force=True."""
    cached = None
    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            cached = json.load(f)
    except Exception:
        pass
    if cached and not force and time.time() - cached.get("time", 0) < CHANNELS_MAX_AGE:
        return cached["channels"]
    try:
        channels = discover(log)
        if not channels:
            raise RuntimeError("nessun canale trovato")
    except Exception as e:
        log("discover fallito: %s" % e)
        if cached:
            return cached["channels"]  # meglio una lista vecchia che niente
        raise
    try:
        os.makedirs(os.path.dirname(cache_file), exist_ok=True)
        tmp = cache_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"time": time.time(), "channels": channels}, f, ensure_ascii=False)
        os.replace(tmp, cache_file)
    except Exception as e:
        log("scrittura cache: %s" % e)
    return channels


# ---------------------------------------------------------------- token + HLS

class TokenCache(object):
    """Token Easybroadcast per URL master, rinnovato 2 minuti prima della scadenza."""

    def __init__(self):
        self._lock = threading.Lock()
        self._cache = {}

    def get(self, url):
        with self._lock:
            q, exp = self._cache.get(url, (None, 0))
            if q and exp - time.time() > 120:
                return q
        q = fetch(TOKEN_URL.format(url=urllib.parse.quote(url, safe=""))).strip()
        if "token=" not in q:
            raise RuntimeError("risposta token non valida: %r" % q[:100])
        try:
            exp = int(urllib.parse.parse_qs(q)["expires"][0])
        except Exception:
            exp = time.time() + 600
        with self._lock:
            self._cache[url] = (q, exp)
        return q

    def clear(self):
        with self._lock:
            self._cache.clear()


def with_query(url, q):
    return url + ("&" if "?" in url else "?") + q


def rewrite_playlist(text, base, fn):
    """Applica fn(url_assoluto) a ogni riga URI della playlist (anche URI="..." nei tag)."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            line = fn(urllib.parse.urljoin(base, s))
        elif 'URI="' in s:
            line = re.sub(r'URI="([^"]+)"',
                          lambda m: 'URI="%s"' % fn(urllib.parse.urljoin(base, m.group(1))), line)
        out.append(line)
    return "\n".join(out) + "\n"
